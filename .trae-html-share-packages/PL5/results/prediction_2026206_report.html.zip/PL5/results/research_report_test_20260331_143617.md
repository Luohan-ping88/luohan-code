# 排列五研究分析报告
生成时间: 2026-03-31T14:36:17.284286

## 基本统计信息
- wan位: 均值=4.53, 标准差=2.86, 范围=0-9, 众数=8
- qian位: 均值=4.54, 标准差=2.88, 范围=0-9, 众数=9
- bai位: 均值=4.54, 标准差=2.86, 范围=0-9, 众数=4
- shi位: 均值=4.50, 标准差=2.86, 范围=0-9, 众数=4
- ge位: 均值=4.52, 标准差=2.85, 范围=0-9, 众数=2

## 模式分析
### consecutive_patterns
- wan位: {'max_consecutive': 4, 'consecutive_count': 692}
- qian位: {'max_consecutive': 5, 'consecutive_count': 668}
- bai位: {'max_consecutive': 4, 'consecutive_count': 647}
- shi位: {'max_consecutive': 4, 'consecutive_count': 686}
- ge位: {'max_consecutive': 5, 'consecutive_count': 711}

### repeat_patterns
- wan位: {'most_common_value': 8, 'most_common_count': 800, 'repeat_ratio': 0.10590415673815197}
- qian位: {'most_common_value': 9, 'most_common_count': 786, 'repeat_ratio': 0.10405083399523431}
- bai位: {'most_common_value': 4, 'most_common_count': 833, 'repeat_ratio': 0.11027270320360075}
- shi位: {'most_common_value': 4, 'most_common_count': 821, 'repeat_ratio': 0.10868414085252846}
- ge位: {'most_common_value': 2, 'most_common_count': 800, 'repeat_ratio': 0.10590415673815197}

### alternating_patterns
- wan位: {'alternating_count': 654, 'alternating_ratio': 0.08659957627118645}
- qian位: {'alternating_count': 701, 'alternating_ratio': 0.09282309322033898}
- bai位: {'alternating_count': 671, 'alternating_ratio': 0.08885063559322035}
- shi位: {'alternating_count': 717, 'alternating_ratio': 0.0949417372881356}
- ge位: {'alternating_count': 626, 'alternating_ratio': 0.08289194915254237}

### trend_patterns
- wan位: {'increasing_count': 3380, 'decreasing_count': 3411, 'trend_bias': -0.004104329405534225}
- qian位: {'increasing_count': 3403, 'decreasing_count': 3412, 'trend_bias': -0.0011915795048325168}
- bai位: {'increasing_count': 3409, 'decreasing_count': 3418, 'trend_bias': -0.0011915795048325168}
- shi位: {'increasing_count': 3396, 'decreasing_count': 3387, 'trend_bias': 0.0011915795048325168}
- ge位: {'increasing_count': 3360, 'decreasing_count': 3402, 'trend_bias': -0.005560704355885079}

## 异常检测
- wan位: 异常数量=0, 异常比例=0.00
- qian位: 异常数量=0, 异常比例=0.00
- bai位: 异常数量=0, 异常比例=0.00
- shi位: 异常数量=0, 异常比例=0.00
- ge位: 异常数量=0, 异常比例=0.00

## 趋势分析
- wan位: 趋势=decreasing, 斜率=-0.0000
- qian位: 趋势=decreasing, 斜率=-0.0000
- bai位: 趋势=decreasing, 斜率=-0.0000
- shi位: 趋势=increasing, 斜率=0.0000
- ge位: 趋势=decreasing, 斜率=-0.0000

## 相关性分析
- shi_ge: -0.0215
- bai_ge: 0.0184
- qian_shi: 0.0131
- bai_shi: -0.0100
- qian_bai: 0.0084